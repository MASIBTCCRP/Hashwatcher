HashWatcher by Masimoto — GitHub Pages deployment

1. Create a PUBLIC repository named hashwatcher.
2. Upload index.html to the repository root.
3. Commit the file to the main branch.
4. Open Settings > Pages.
5. Under Build and deployment choose Deploy from a branch.
6. Select branch main and folder /(root), then Save.
7. Wait for deployment and open the Visit site URL.

Security notes:
- The Supabase publishable key in index.html is intended for client use. Protect all database tables with Row Level Security policies.
- Never add service_role or sb_secret keys to this repository.
- GitHub Pages sites are publicly accessible. Do not upload private files, credentials, or personal data.
